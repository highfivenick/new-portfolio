Files used by [package.sh](../package.sh), the script that creates the .pkg installer.
